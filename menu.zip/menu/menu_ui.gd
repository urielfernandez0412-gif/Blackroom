extends Control

@onready var btn_crear = $VBoxContainer/BtnCrear
@onready var btn_unirse = $VBoxContainer/HBoxContainer/BtnUnirse
@onready var ip_input = $VBoxContainer/HBoxContainer/IpInput
@onready var estado_label = $VBoxContainer/EstadoLabel
@onready var btn_salir = $VBoxContainer/BtnSalir
@onready var gm = preload("res://game_manager.gd").new()

func _ready():
	add_child(gm)
	btn_crear.pressed.connect(_on_crear_pressed)
	btn_unirse.pressed.connect(_on_unirse_pressed)
	btn_salir.pressed.connect(get_tree().quit)
	
	estado_label.text = "Desconectado"
	ip_input.text = get_ip_local()
	
func _on_crear_pressed():
	estado_label.text = "Creando servidor..."
	btn_crear.disabled = true
	btn_unirse.disabled = true
	
	gm.crear_partida()
	
	await get_tree().create_timer(1.0).timeout
	gm.cambiar_nivel(1)

func _on_unirse_pressed():
	var ip = ip_input.text.strip_edges()
	if ip == "":
		estado_label.text = "192.168.10.100"
		return
	estado_label.text = "Conectando a" + ip + "..."
	gm.unirse_partida(ip)
	
func get_ip_local():
	for ip in IP.get_local_addresses():
		if ip.begins_with("192.168.") or ip.begins_with("10."):
			return ip
	return "127.0.0.1"
